import os
from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
MODEL = os.environ.get("GROQ_MODEL", "openai/gpt-oss-20b")

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/chat")
def chat():
    if not GROQ_API_KEY:
        return jsonify({"error": "ИИ пока не настроен. Владелец сайта должен добавить GROQ_API_KEY в настройки сервера."}), 503

    data = request.get_json(silent=True) or {}
    messages = data.get("messages", [])
    if not isinstance(messages, list) or not messages:
        return jsonify({"error": "Напиши сообщение и попробуй ещё раз."}), 400

    # Keep requests small and do not trust client-supplied system instructions.
    safe_messages = [{
        "role": "system",
        "content": "Ты ALIZHAN AI — дружелюбный помощник. Отвечай понятно, полезно и на языке пользователя."
    }]
    for item in messages[-12:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        content = item.get("content")
        if role not in ("user", "assistant") or not isinstance(content, str):
            continue
        safe_messages.append({"role": role, "content": content[:4000]})

    try:
        r = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {GROQ_API_KEY}",
                     "Content-Type": "application/json"},
            json={"model": MODEL, "messages": safe_messages, "max_tokens": 800},
            timeout=60
        )
        if r.status_code != 200:
            # Don't expose provider response details or secrets to visitors.
            return jsonify({"error": f"Сервис ИИ временно не ответил (код {r.status_code}). Попробуй позже."}), 502
        answer = r.json()["choices"][0]["message"]["content"]
        return jsonify({"reply": answer})
    except requests.RequestException:
        return jsonify({"error": "Не удалось связаться с ИИ. Попробуй позже."}), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "10000")))
